================================
= ORSYP $Universe Status Check =
=         By Tim Hosey         =
=    http://www.zomgrei.com    =
================================

The ORSYP $Universe status check script is a Powershell-based utility that uses the built-in UXSHW tool in the ORSYP toolkit to check for Launch Wait jobs and compare their timing to the current time. Using Jenkins to run it every six hours, if any job is one hour or more beyond the Launch Window, it will email an alert to the appropriate people.

This can be adapted to use any scheduling tool, including Windows Scheduler, but will require a little more work on your end, as Jenkins has e-mail capabilities built-in and Windows Scheduler requires extra scripts to be able to do that.

1. What's Included
Included is a bat file (orsyp_launch_wait_check.bat) and a Powershell script (getList.ps1).

The bat file loads the environment variables and then kicks off the Powershell script.

The Powershell script launches UXSHW and fails if there are any jobs whatsoever in Launch Wait an hour or more past their launch window.

2.Usage
Tweak the scripts to point to the correct locations; in orsyp_launch_wait_check.bat, change the CALL to the uxsetenv.bat to point to the correct folder. Then, change to the correct env name in getList.ps1 - at the top, change SIM to EXP or another appropriate environment name.

Then configure a scheduler of some kind (I highly recommend against setting it up in ORSYP $Universe Scheduler as if something is wacky with the scheduler, the check may not kick off) to launch the script on the scheduler server. From Jenkins, I configured Execute Windows Batch Command to use the following script:

powershell invoke-command -ComputerName <SERVERNAME> -ScriptBlock {c:\scripts\orsyp_launch_wait_check.bat}

Make sure you have Powershell remoting enabled on the ORSYP $Universe Scheduler server.

The job will fail with an errorlevel of 1 if there are jobs stuck past their launch wait window.

3. Licensing
This is completely free & open source, meaning you're absolutely free to use it, dismantle it, adapt it and change it as you see fit. It uses ORSYP's built-in tools, so licensing for ORSYP is necessitated, but for this script you don't need anything special.