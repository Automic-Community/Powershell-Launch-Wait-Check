function Get-Tasks {
	# Change SIM to the correct name, eg EXP, S or E
	& $env:UXEXE\UXSHW FLA SIM MU=* NSEQ=* UPR=* VUPR=* STATUS=L VUPR=*
}

Write-Host "`r`n** Getting tasklist..."

$tasks = Get-Tasks

# sorts the tasks retrieved from Get-Tasks into more manageable format
$sortedTasks = $tasks | Sort

# init our failed variable
$failed = 0

Write-Host "`r`n** Parsing and comparing tasks to current time..."
$sortedTasks | Select-String "lstart" | %{
	$str = $_
	# Wiping out the gunk before the date/time of the Launch Wait stuff
	$str = $str -Replace "       \| lstart       \: ",""
	# Replace the open paren
	$str = $str -Replace "\(",""
	# Replace close paren
	$str = $str -Replace "\)",""
	# Split the date and time by comma
	$str = $str -Split ","
	# Get current date/time
	$thisDate = Get-Date
	# initialize the increment number
	$i = 0
	# %{} is a foreach-object shorthand
	$str | %{
		# if it's the first part of the string...
		if ($i -eq 0) {
			# splits out the date 
			$taskDate = $_ -Split "/"
			# set our increment to 1
			$i = 1
		} else {
			# makes the task time an integer with the time
			[int]$taskTime = $_
			# set the cur hour to a str
			[String]$thisHour = $thisDate.Hour
			# set the cur minute to a str
			[String]$thisMinute = $thisDate.Minute
			# set the time to a concatenated string
			[String]$thisTimeConcat = $thisHour+$thisMinute
			# convert string time to an integer
			[int]$thisTime = $thisTimeConcat
			# set the month of the task
			[int]$taskMonth = $taskDate[0]
			# set the day of the task
			[int]$taskDay = $taskDate[1]
			# set the year of the task
			[int]$taskYear = $taskDate[2]
			# set the cur day
			[int]$thisDay = $thisDate.Day
			# set the cur month
			[int]$thisMonth = $thisDate.Month
			# set the cur year
			[int]$thisYear = $thisDate.Year
			# if the taskday, taskmonth, or taskyear is less than or equal to today, then we'll inspect it closer;
			# else it will be ignored
			if (($taskDay -le $thisDay) -or ($taskMonth -le $thisMonth) -or ($taskYear -le $thisYear)) {
				# if the tasktime is an hour or more behind the cur time, or the taskday is less than today, the task month
				# is less than this month, or the taskyear is less than this year, we increment the failed counter by 1
				if (((($thisTime - $taskTime) -gt 100) -and ($taskDay -eq $thisDay) -and ($taskMonth -eq $thisMonth) -and ($taskYear -eq $thisYear)) -or (($taskDay -lt $thisDay) -and ($taskMonth -eq $thisMonth) -and ($taskYear -eq $thisYear)) -or (($taskMonth -lt $thisMonth) -and ($taskYear -eq $thisYear)) -or ($taskYear -lt $thisYear)) {
					# increment failed counter
					$failed++
				}
			}
			# set our increment to 0 to start the process over
			$i = 0
		}
	}
}

# if we have 1 or more failed jobs, we notify
if ($failed -gt 0 ) {
	Write-Host "`r`n** $failed jobs stuck!"
	exit $failed
# if we have no failed jobs, we post to stdout and exit with a 0
} else {
	Write-Host "`r`n** No stuck jobs; everything is okay for now."
	exit 0
}